var Aluno1={
    RA: "003048222101",
    Nome: "Jorge"
};

document.write("1ª forma:");
document.write("<br><br>RA: " + Aluno1.RA + "<br>Nome: " + Aluno1.Nome);

var Aluno1 = new Object();
Aluno1.RA = "003048222102";
Aluno1.Nome = "Rita";

document.write("<br><br>2ª forma:");
document.write("<br><br>RA: " + Aluno1.RA + "<br>Nome: " + Aluno1.Nome);

var Aluno1 = {};
var RA = 'RA';
var Nome = 'Nome';
Aluno1[RA] = "003048222103";
Aluno1[Nome] = "Gabriel";

document.write("<br><br>3ª forma:");
document.write("<br><br>RA: " + Aluno1.RA + "<br>Nome: " + Aluno1.Nome);