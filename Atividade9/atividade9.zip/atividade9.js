alert("Qual o maior número?");
num1 = parseInt(prompt("Digite um número: "));
num2 = parseInt(prompt("Digite outro número: "));
num3 = parseInt(prompt("Digite mais um número: "));

function maior (n1, n2, n3){
    var num = [n1, n2, n3];

    maior = Math.max.apply(null, num);

    document.write("O maior número é " + maior);
}

maior(num1, num2, num3);

alert("Qual a ordem numérica?");
num11 = parseInt(prompt("Digite um número: "));
num22 = parseInt(prompt("Digite outro número: "));
num33 = parseInt(prompt("Digite mais um número: "));

function ordenar (n1, n2, n3) {
    var num = [n1, n2, n3];

    num.sort(function(a, b){return a-b});

    document.write("<br><br>Os número em ordem crescente ficam: " + num);
}

ordenar(num11, num22, num33);