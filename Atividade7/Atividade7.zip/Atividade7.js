opc = 1;
while (opc == 1) {
    player = prompt("Escolha: \n1 - Pedra \n2 - Papel \n3 - Tesoura");

    cpu = Math.random();

    if (cpu <= 0.33) {
        cpu = 1;
    }

    else if (cpu > 0.33 && cpu <= 0.66) {
        cpu = 2;
    }

    else {
        cpu = 3;
    }

    if (cpu == 1) {
        alert("O CPU escolheu pedra ✍(◔◡◔)");
    }

    else if (cpu == 2) {
        alert("O CPU escolheu papel ✍(◔◡◔)");
    }

    else {
        alert("O CPU escolheu tesoura ✍(◔◡◔)");
    }

    if (player == cpu) {
        alert("Empate! (⊙.⊙)");
    }

    else if (player == 1) {
        if (cpu == 2) {
            alert("Papel cobre pedra. \nO CPU Venceu! ( ͡ಠ ͜ʖ ͡ಠ)");
        }
        else {
            alert("Pedra quebra tesoura. \nVocê Venceu!!! (っ＾▿＾)۶");
        }
    }

    else if (player == 2) {
        if (cpu == 1) {
            alert("Papel cobre pedra. \nVocê Venceu!!! (っ＾▿＾)۶");
        }
        else {
            alert("Tesoura corta papel. \nCPU Venceu! ( ͡ಠ ͜ʖ ͡ಠ)");
        }
    }

    else if (player == 3) {
        if (cpu == 1) {
            alert("Pedra quebra tesoura. \nCPU Venceu! ( ͡ಠ ͜ʖ ͡ಠ)");
        }
        else {
            alert("Tesoura corta papel. \nVocê Venceu!!! (っ＾▿＾)۶");
        }
    }

    opc = prompt("Quer jogar de novo? \n1 - Sim \n2 - Não")
}