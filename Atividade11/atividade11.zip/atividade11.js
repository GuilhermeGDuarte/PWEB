class Retangulo {
    constructor(x, y) {
        this.altura = x;
        this.base = y;
    }

    calculaArea() {
        return this.altura * this.base;
    }
}

altura = parseInt(prompt("Digite a altura do retângulo:"));
base = parseInt(prompt("Digite a base do retângulo:"));

objRet = new Retangulo(altura, base);

document.write("Exercício 1: ");
document.write("<br>A área do retângulo é: " + objRet.calculaArea());

function Conta() {
    var nomeCorr;
    var banco;
    var numConta;
    var saldo;

    this.getNomeCorr = function () {
        return nomeCorr;
    }

    this.setNomeCorr = function (value) {
        nomeCorr = value;
    }

    this.getBanco = function () {
        return banco;
    }

    this.setBanco = function (value) {
        banco = value;
    }

    this.getNumConta = function () {
        return numConta;
    }

    this.setNumConta = function (value) {
        numConta = value;
    }

    this.getSaldo = function () {
        return saldo;
    }

    this.setSaldo = function (value) {
        saldo = value;
    }
}

function Corrente() {
    var saldoEsp;

    this.getSaldoEsp = function () {
        return saldoEsp;
    }

    this.setSaldoEsp = function (value) {
        saldoEsp = value;
    }
}

function Poupanca() {
    var juros;
    var dataVen;

    this.getJuros = function () {
        return juros;
    }

    this.setJuros = function (value) {
        juros = value;
    }

    this.getDataVen = function () {
        return dataVen;
    }

    this.setDataVen = function (value) {
        dataVen = value;
    }
}

Corrente.prototype = new Conta();
Poupanca.prototype = new Conta();

nCorrente = new Corrente();
nPoupanca = new Poupanca();

nCorrente.setNomeCorr("João");
nCorrente.setBanco("Itaú");
nCorrente.setNumConta("1234");
nCorrente.setSaldo(1200);
nCorrente.setSaldoEsp(500);

document.write("<br><br>Exercício 2: ");
document.write("<br><br>Conta Corrente: <br><br>Nome: " + nCorrente.getNomeCorr() + "<br>Banco: " + nCorrente.getBanco() + "<br>Número da conta: " + nCorrente.getNumConta() + 
"<br>Saldo: " + nCorrente.getSaldo() + "<br>Saldo especial: " + nCorrente.getSaldoEsp());

nPoupanca.setNomeCorr("Maria");
nPoupanca.setBanco("Santander");
nPoupanca.setNumConta("4321");
nPoupanca.setSaldo(1350);
nPoupanca.setJuros("5%");
nPoupanca.setDataVen("05/11");

document.write("<br><br>Conta Poupança: <br><br>Nome: " + nPoupanca.getNomeCorr() + "<br>Banco: " + nPoupanca.getBanco() + "<br>Número da conta: " + nPoupanca.getNumConta() + 
"<br>Saldo: " + nPoupanca.getSaldo() + "<br>Juros: " + nPoupanca.getJuros() + "<br>Data de vencimento: " + nPoupanca.getDataVen());