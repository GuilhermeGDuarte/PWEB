(function($){
  $(function(){

    $('.sidenav').sidenav();
    $('.parallax').parallax();

  }); // end of document ready
})(jQuery); // end of jQuery name space

$(document).ready(function(){
  $('.carousel').carousel();
});

$('.carousel').carousel();
setInterval(function() {
  $('.carousel').carousel('next');
}, 3000);

$('.carousel.carousel-slider').carousel({
  fullWidth: true
});

const start = () => {
  setTimeout(function() {
      confetti.start()
  }, 1000);
};

const stop = () => {
  setTimeout(function() {
      confetti.stop()
  }, 5000);
};

start();
stop();
