cont = 0, contPes = 0, contOtBm = 0, contF = 0, contM = 0, somaId = 0, idVel = -10000000000, idNov = 10000000000;

while (cont < 3)
{
    idade = prompt("Digite sua idade: ");
    sexo = prompt("Digite seu sexo: \n1 - M \n2 - F");
    opin = prompt("Digite sua avaliação: \n4 - Ótimo \n3 - Bom \n2 - Regular \n1 - Péssimo");

    somaId += parseInt(idade);

    if (parseInt(idade) > idVel)
    {
        idVel = parseInt(idade);
    }

    else if (parseInt(idade) < idNov)
    {
        idNov = parseInt(idade);
    }

    if (opin == 1)
    {
        contPes++;
    }

    else if (opin == 4 || opin == 3)
    {
        contOtBm++;
    }

    if (parseInt(sexo) == 1)
    {
        contM++;
    }

    else
    {
        contF++;
    }

    cont++;
}

media = somaId / cont;

porcOtBm = (contOtBm / cont) * 100;

document.write("A média de idade das pessoas que responderam ao questionário é de " + media + " anos;" +
"<br><br>A idade da pessoa mais velha possui " + idVel + " anos;" + 
"<br><br>A idade da pessoa mais nova possui " + idNov + " anos;" + 
"<br><br>" + idNov + " pessoas responderam péssimo;" + 
"<br><br>" + porcOtBm.toFixed(2) + "% das pessoas responderam ótimo ou bom;" + 
"<br><br>Deles, " + contF + " são mulheres e " + contM + " são homens.");